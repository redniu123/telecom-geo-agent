"""Plain-Python conversational controller over the frozen P0 Workflow."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any, Protocol

from agent.outputs import write_outputs
from agent.state import AgentState
from agent.workflow import run_workflow
from telecom_core.data_loader import load_demo_network
from telecom_core.models import NetworkData

from .layer_plan import LayerPlan, build_layer_plan


class ChatView(Protocol):
    def append_message(self, role: str, text: str, kind: str = "info") -> None: ...

    def clear_conversation(self) -> None: ...

    def set_status(self, text: str, state: str = "idle") -> None: ...

    def set_actions_enabled(self, enabled: bool) -> None: ...


class MapPort(Protocol):
    def load_plan(self, plan: LayerPlan) -> None: ...

    def show_first_route(self) -> None: ...

    def show_final_route(self) -> None: ...

    def focus_issue(self, asset_id: str) -> None: ...


WorkflowRunner = Callable[[str], AgentState]
OutputWriter = Callable[[AgentState, str | Path], list[Path]]
NetworkLoader = Callable[[], NetworkData]


class ChatController:
    """Classify fixed local intents and present real P0 state in order."""

    def __init__(
        self,
        view: ChatView,
        map_port: MapPort,
        repository_root: str | Path,
        *,
        workflow_runner: WorkflowRunner = run_workflow,
        output_writer: OutputWriter = write_outputs,
        network_loader: NetworkLoader = load_demo_network,
    ) -> None:
        self.view = view
        self.map_port = map_port
        self.repository_root = Path(repository_root).resolve()
        self.workflow_runner = workflow_runner
        self.output_writer = output_writer
        self.network_loader = network_loader
        self.last_state: AgentState | None = None
        self.layer_plan: LayerPlan | None = None
        self.view.set_actions_enabled(False)

    @staticmethod
    def classify_intent(text: str) -> str:
        compact = "".join(text.strip().split())
        upper = compact.upper()
        if "清空" in compact and ("对话" in compact or "聊天" in compact):
            return "clear"
        if "解释" in compact and ("失败" in compact or "D017" in upper):
            return "explain_failure"
        if ("定位" in compact or "缩放" in compact) and (
            "问题" in compact or "D017" in upper
        ):
            return "focus_issue"
        if "第一次路线" in compact or "初次路线" in compact:
            return "show_first"
        if "最终路线" in compact or "第二次路线" in compact:
            return "show_final"
        if "BOM" in upper or "材料清单" in compact:
            return "show_bom"
        if "规划" in compact and "到" in compact and "芯" in compact:
            return "run_plan"
        return "unknown"

    def handle_user_input(self, text: str) -> None:
        request = text.strip()
        if not request:
            return
        intent = self.classify_intent(request)
        if intent == "clear":
            self.view.clear_conversation()
            self.view.append_message(
                "assistant",
                "对话已清空；已加载的地图结果和本次规划上下文仍保留。",
            )
            self.view.set_status("就绪", "idle")
            return

        self.view.append_message("user", request)
        try:
            if intent == "run_plan":
                self._run_plan(request)
                return
            elif intent == "explain_failure":
                self._explain_failure()
            elif intent == "focus_issue":
                self._require_completed_state()
                self.map_port.focus_issue("D017")
                self.view.append_message(
                    "assistant", "已定位并标红 D017 合成 P0 测试段。", "map"
                )
            elif intent == "show_first":
                self._require_completed_state()
                self.map_port.show_first_route()
                self.view.append_message(
                    "assistant", "地图已切换到第一次路线 R001（包含 D017）。", "map"
                )
            elif intent == "show_final":
                self._require_completed_state()
                self.map_port.show_final_route()
                self.view.append_message(
                    "assistant", "地图已切换到最终路线 R002（绕开 D017）。", "map"
                )
            elif intent == "show_bom":
                state = self._require_completed_state()
                self.view.append_message("assistant", self._bom_text(state), "bom")
            else:
                self.view.append_message(
                    "assistant",
                    "首版仅支持确定性指令：运行规划、解释失败、定位问题段、"
                    "显示第一次路线、显示最终路线、查看 BOM、清空对话。",
                    "warning",
                )
            self.view.set_status("就绪", "idle")
        except Exception as exc:
            self.view.append_message(
                "assistant", f"执行失败：{type(exc).__name__}: {exc}", "error"
            )
            self.view.set_status("执行失败", "error")

    def _run_plan(self, request: str) -> None:
        self.view.set_status("正在运行确定性 P0 Workflow…", "running")
        self.view.set_actions_enabled(False)
        state = self.workflow_runner(request)
        self.last_state = state
        self.output_writer(state, self.repository_root / "outputs")
        if state["status"] != "completed":
            self.view.append_message(
                "assistant", f"P0 Workflow 未通过：{state['error'] or '未知错误'}", "error"
            )
            self.view.set_status("Workflow 失败", "error")
            return

        first_route = state["first_route"]
        final_route = state["final_route"]
        if first_route is None or final_route is None or state["bom_result"] is None:
            raise RuntimeError("completed 状态缺少路线或 BOM")
        if len(state["validation_history"]) < 2:
            raise RuntimeError("P0 主 Case 未保留两次校核记录")

        plan = build_layer_plan(self.repository_root)
        plan.validate_sources()
        self.map_port.load_plan(plan)
        self.layer_plan = plan

        self.view.append_message(
            "assistant",
            "第一次路线 R001：" + " → ".join(first_route["edge_ids"]),
            "route",
        )
        self._explain_failure(add_heading=False)
        self.view.append_message(
            "assistant",
            "自动修复：禁用问题段 D017；repair_count=1。",
            "repair",
        )
        self.view.append_message(
            "assistant",
            "重新规划 R002：" + " → ".join(final_route["edge_ids"]),
            "route",
        )
        self.view.append_message("assistant", "最终校核：PASS", "success")
        self.view.append_message("assistant", self._bom_text(state), "bom")
        self.map_port.show_final_route()
        self.view.set_actions_enabled(True)
        self.view.set_status("完成 · 最终 PASS", "success")

    def _require_completed_state(self) -> AgentState:
        state = self.last_state
        if state is None or state["status"] != "completed":
            raise RuntimeError("请先输入“从A到B规划24芯光缆”运行本次规划")
        return state

    def _explain_failure(self, *, add_heading: bool = True) -> None:
        state = self._require_completed_state()
        first_validation = state["validation_history"][0]
        violation = next(
            (
                item
                for item in first_validation["violations"]
                if item.get("rule_id") == "R_CAPACITY"
                and item.get("asset_id") == "D017"
            ),
            None,
        )
        if violation is None:
            raise RuntimeError("第一次校核中没有 R_CAPACITY/D017 事实")
        edge = self.network_loader().edge_records["D017"]
        capacity = int(edge["capacity_cores"])
        used = int(edge["used_cores"])
        remaining = capacity - used
        requested = int(state["task"]["fiber_cores"]) if state["task"] else 0
        prefix = "失败解释：" if add_heading else "第一次校核：FAIL / R_CAPACITY。"
        self.view.append_message(
            "assistant",
            f"{prefix}D017 是仓库内合成 P0 测试段，不是现实管道。"
            f"总容量 {capacity} 芯，已用 {used} 芯，剩余 {remaining} 芯，"
            f"小于本次 {requested} 芯需求。",
            "warning",
        )

    @staticmethod
    def _bom_text(state: AgentState) -> str:
        bom = state["bom_result"]
        if bom is None:
            raise RuntimeError("当前结果没有 BOM")
        return (
            "BOM（由最终路线复算）："
            f"总长 {bom['total_length_m']:.2f} m；"
            f"已有管道 {bom['existing_duct_length_m']:.2f} m；"
            f"新建 {bom['new_build_length_m']:.2f} m；"
            f"建议光缆 {bom['recommended_cable_length_m']:.2f} m；"
            "used_edge_ids=" + " → ".join(bom["used_edge_ids"])
        )
